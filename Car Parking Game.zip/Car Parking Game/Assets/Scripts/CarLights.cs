using UnityEngine;
using UnityEngine.InputSystem;

// Car ki lights.
// Brake lights (peeche, laal): brake dabane par ya reverse gear mein jalti hain
// Headlights (aage, peeli): H key se on / off
public class CarLights : MonoBehaviour
{
    public CarController car;            // khaali chhoro, khud mil jayega

    [Header("Brake lights (peeche)")]
    public Renderer[] brakeLights;       // BrakeLightL, BrakeLightR
    public Material brakeOff;            // BrakeLight_Off
    public Material brakeOn;             // BrakeLight_On
    public Light brakeGlow;              // BrakeGlow (laal Point Light)

    [Header("Headlights (aage)")]
    public Renderer[] headlightBulbs;    // HeadlightL, HeadlightR
    public Material headOff;             // Headlight_Off
    public Material headOn;              // Headlight_On
    public Light[] headlightBeams;       // BeamL, BeamR (Spot Lights)
    public bool headlightsOn = true;

    void Start()
    {
        if (car == null) car = GetComponent<CarController>();
        SetHeadlights(headlightsOn);
    }

    void Update()
    {
        // H = headlights on / off
        Keyboard kb = Keyboard.current;
        if (kb != null && kb.hKey.wasPressedThisFrame)
        {
            headlightsOn = !headlightsOn;
            SetHeadlights(headlightsOn);
        }

        // Brake ya reverse = laal lights on
        bool brakeLit = car != null && (car.isBraking || car.isReverse);

        foreach (Renderer r in brakeLights)
        {
            if (r != null) r.sharedMaterial = brakeLit ? brakeOn : brakeOff;
        }
        if (brakeGlow != null) brakeGlow.enabled = brakeLit;
    }

    void SetHeadlights(bool on)
    {
        foreach (Renderer r in headlightBulbs)
        {
            if (r != null) r.sharedMaterial = on ? headOn : headOff;
        }
        foreach (Light l in headlightBeams)
        {
            if (l != null) l.enabled = on;
        }
    }
}
