using UnityEngine;

// Object ko aahista aahista ghumata hai (menu wali car ke liye)
public class Spinner : MonoBehaviour
{
    public float speed = 20f;

    void Update()
    {
        transform.Rotate(0f, speed * Time.deltaTime, 0f);
    }
}
