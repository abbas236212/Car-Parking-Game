using UnityEngine;

// Parking spot: car poori andar ho aur ruki ho (1 second) = LEVEL COMPLETED
public class ParkingSpot : MonoBehaviour
{
    public float stopSpeed = 0.3f;   // is se kam speed = ruki hui
    public float holdTime = 1f;      // kitne second ruke rehna hai

    Collider spot;
    float timer = 0f;
    bool done = false;

    void Start()
    {
        spot = GetComponent<Collider>();
    }

    void OnTriggerEnter(Collider other)
    {
        // Car ko "sone" na do, warna check ruk jata hai
        if (other.attachedRigidbody != null) other.attachedRigidbody.sleepThreshold = 0f;
    }

    void OnTriggerStay(Collider other)
    {
        if (done) return;

        CarController car = other.GetComponentInParent<CarController>();
        if (car == null) return;

        // Car ka poora dabba spot ke andar hai? (aage-peeche aur left-right)
        Bounds s = spot.bounds;
        Bounds c = other.bounds;
        bool inside = c.min.x >= s.min.x && c.max.x <= s.max.x &&
                      c.min.z >= s.min.z && c.max.z <= s.max.z;

        if (inside && Mathf.Abs(car.currentSpeed) < stopSpeed)
        {
            timer += Time.fixedDeltaTime;
            if (timer >= holdTime)
            {
                done = true;
                if (GameManager.Instance != null) GameManager.Instance.LevelComplete();
            }
        }
        else
        {
            timer = 0f;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.GetComponentInParent<CarController>() != null) timer = 0f;
    }
}
