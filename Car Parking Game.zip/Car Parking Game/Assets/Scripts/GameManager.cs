using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Game ka "dimagh": Level Complete, Level Failed, Next, Restart, Menu
public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public CarController car;                    // PlayerCar

    [Header("Level Complete")]
    public GameObject completePanel;             // CompletePanel
    public ParticleSystem confetti;              // Confetti
    public AudioSource winSound;                 // WinSound

    [Header("Level Failed (Phase 6)")]
    public GameObject failPanel;                 // FailPanel
    public AudioSource failSound;                // FailSound
    public GameObject redFlash;                  // RedFlash

    [Header("Scenes")]
    public string nextSceneName = "Level2";      // NEXT dabane par ye scene khulega
    public string menuSceneName = "MainMenu";    // MENU dabane par

    bool gameOver = false;

    void Awake()
    {
        Instance = this;
        Time.timeScale = 1f;
    }

    void Start()
    {
        if (completePanel != null) completePanel.SetActive(false);
        if (failPanel != null) failPanel.SetActive(false);
        if (redFlash != null) redFlash.SetActive(false);
    }

    // ParkingSpot is ko call karta hai
    public void LevelComplete()
    {
        if (gameOver) return;
        gameOver = true;

        if (car != null) car.StopCar();
        if (completePanel != null) completePanel.SetActive(true);
        if (confetti != null) confetti.Play();
        if (winSound != null) winSound.Play();

        // Agla level unlock (Level Select ke liye, Phase 9)
        int current = GetLevelNumber();
        int unlocked = PlayerPrefs.GetInt("UnlockedLevel", 1);
        if (current + 1 > unlocked)
        {
            PlayerPrefs.SetInt("UnlockedLevel", current + 1);
            PlayerPrefs.Save();
        }
    }

    // CrashDetector is ko call karta hai (Phase 6)
    public void LevelFailed()
    {
        if (gameOver) return;
        gameOver = true;

        if (car != null) car.StopCar();
        if (failPanel != null) failPanel.SetActive(true);
        if (failSound != null) failSound.Play();
        if (redFlash != null) StartCoroutine(Flash());
    }

    IEnumerator Flash()
    {
        for (int i = 0; i < 3; i++)
        {
            redFlash.SetActive(true);
            yield return new WaitForSecondsRealtime(0.12f);
            redFlash.SetActive(false);
            yield return new WaitForSecondsRealtime(0.12f);
        }
    }

    public bool IsGameOver()
    {
        return gameOver;
    }

    // ---------- Buttons ----------
    public void NextLevel()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(nextSceneName);
    }

    public void Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void Menu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(menuSceneName);
    }

    int GetLevelNumber()
    {
        string sceneName = SceneManager.GetActiveScene().name;   // jaise "Level1"
        int number;
        if (int.TryParse(sceneName.Replace("Level", ""), out number)) return number;
        return 1;
    }
}
