using UnityEngine;
using UnityEngine.InputSystem;

// Car chalane ka script.
// W = gas, S / Space = brake, A / D = mudna, E = gear (D <-> R)
[RequireComponent(typeof(Rigidbody))]
public class CarController : MonoBehaviour
{
    [Header("Speed settings")]
    public float maxSpeed = 8f;          // aage ki top speed (meter per second)
    public float maxReverseSpeed = 4f;   // peeche ki top speed
    public float acceleration = 5f;      // kitni jaldi speed pakarti hai
    public float brakePower = 12f;       // brake kitna tez rokti hai
    public float turnSpeed = 80f;        // mudne ki speed (degree per second)

    [Header("Car ki halat (sirf dekhne ke liye)")]
    public bool isReverse = false;       // false = D (aage), true = R (peeche)
    public float currentSpeed = 0f;      // + aage, - peeche
    public bool isBraking = false;
    public bool controlsEnabled = true;  // game khatam hone par false ho jayega

    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.centerOfMass = new Vector3(0f, -0.3f, 0f); // car ulte nahi
    }

    void Update()
    {
        Keyboard kb = Keyboard.current;
        if (kb == null || !controlsEnabled) return;

        // E dabane par gear badlo, sirf jab car taqreeban ruki hui ho
        if (kb.eKey.wasPressedThisFrame && Mathf.Abs(currentSpeed) < 0.5f)
        {
            isReverse = !isReverse;
        }
    }

    void FixedUpdate()
    {
        Keyboard kb = Keyboard.current;
        bool gas = false;
        bool brake = false;
        float steer = 0f;

        if (kb != null && controlsEnabled)
        {
            gas = kb.wKey.isPressed || kb.upArrowKey.isPressed;
            brake = kb.sKey.isPressed || kb.downArrowKey.isPressed || kb.spaceKey.isPressed;
            if (kb.aKey.isPressed || kb.leftArrowKey.isPressed) steer -= 1f;
            if (kb.dKey.isPressed || kb.rightArrowKey.isPressed) steer += 1f;
        }

        isBraking = brake;

        // Kitni speed chahiye
        float targetSpeed = 0f;
        if (gas && !brake)
        {
            targetSpeed = isReverse ? -maxReverseSpeed : maxSpeed;
        }

        float rate = brake ? brakePower : acceleration;
        currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, rate * Time.fixedDeltaTime);

        // Mudna: sirf jab car chal rahi ho (asli car ki tarah)
        float speedFactor = Mathf.Clamp(currentSpeed / 3f, -1f, 1f);
        float turn = steer * turnSpeed * speedFactor * Time.fixedDeltaTime;
        rb.MoveRotation(rb.rotation * Quaternion.Euler(0f, turn, 0f));

        // Aage / peeche chalna
        Vector3 velocity = transform.forward * currentSpeed;
        velocity.y = rb.linearVelocity.y;
        rb.linearVelocity = velocity;
    }

    // Game khatam (park ya crash) hone par car rok do
    public void StopCar()
    {
        controlsEnabled = false;
        currentSpeed = 0f;
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }
}
