using UnityEngine;
using UnityEngine.InputSystem;

// Camera car ke peeche peeche chalta hai.
// Mouse ka left button daba kar ghumao = camera ghoomta hai
// Mouse scroll = zoom
// Mouse chhor do = thori der baad camera khud car ke peeche aa jata hai
public class CameraFollow : MonoBehaviour
{
    public Transform target;             // yahan PlayerCar daalna hai

    [Header("Distance")]
    public float distance = 8f;
    public float minDistance = 4f;
    public float maxDistance = 15f;
    public float lookHeight = 1f;        // car ke kitna upar dekhe

    [Header("Angle")]
    public float defaultPitch = 25f;     // upar se kitna jhuk kar dekhe
    public float mouseSensitivity = 0.2f;

    [Header("Smooth")]
    public float followSmooth = 5f;      // car ke peeche aane ki raftar
    public float returnDelay = 1.5f;     // mouse chhorne ke kitne second baad wapis aaye
    public float returnSpeed = 2f;

    float yawOffset = 0f;
    float pitch;
    float currentYaw;
    float lastMouseTime = -10f;

    void Start()
    {
        pitch = defaultPitch;
        if (target != null) currentYaw = target.eulerAngles.y;
    }

    void LateUpdate()
    {
        if (target == null) return;

        Mouse mouse = Mouse.current;
        if (mouse != null)
        {
            // Left button daba kar ghumana
            if (mouse.leftButton.isPressed)
            {
                Vector2 delta = mouse.delta.ReadValue();
                yawOffset += delta.x * mouseSensitivity;
                pitch = Mathf.Clamp(pitch - delta.y * mouseSensitivity, 5f, 80f);
                lastMouseTime = Time.unscaledTime;
            }

            // Scroll se zoom
            float scroll = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(scroll) > 0.01f)
            {
                distance = Mathf.Clamp(distance - scroll * 0.01f, minDistance, maxDistance);
            }
        }

        // Mouse chhorne ke baad khud wapis car ke peeche
        if (Time.unscaledTime - lastMouseTime > returnDelay)
        {
            yawOffset = Mathf.Lerp(yawOffset, 0f, returnSpeed * Time.deltaTime);
            pitch = Mathf.Lerp(pitch, defaultPitch, returnSpeed * Time.deltaTime);
        }

        // Car jidhar mude, camera bhi dheere se udhar
        currentYaw = Mathf.LerpAngle(currentYaw, target.eulerAngles.y, followSmooth * Time.deltaTime);

        Quaternion rotation = Quaternion.Euler(pitch, currentYaw + yawOffset, 0f);
        Vector3 lookPoint = target.position + Vector3.up * lookHeight;
        transform.position = lookPoint - rotation * Vector3.forward * distance;
        transform.LookAt(lookPoint);
    }
}
