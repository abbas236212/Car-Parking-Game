using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

// Level Select: jo level unlock hai wo khulta hai, baqi LOCKED
public class LevelSelect : MonoBehaviour
{
    public Button[] levelButtons;            // Level1Button, Level2Button, Level3Button
    public string menuScene = "MainMenu";

    void Start()
    {
        Time.timeScale = 1f;
        int unlocked = PlayerPrefs.GetInt("UnlockedLevel", 1);

        for (int i = 0; i < levelButtons.Length; i++)
        {
            int levelNumber = i + 1;
            bool open = levelNumber <= unlocked;

            levelButtons[i].interactable = open;

            TextMeshProUGUI t = levelButtons[i].GetComponentInChildren<TextMeshProUGUI>();
            if (t != null) t.text = open ? levelNumber.ToString() : "LOCK";
        }
    }

    // Button ke On Click mein number likhna hai: 1, 2 ya 3
    public void LoadLevel(int levelNumber)
    {
        SceneManager.LoadScene("Level" + levelNumber);
    }

    public void Back()
    {
        SceneManager.LoadScene(menuScene);
    }

    // Demo se pehle sab levels dobara lock karne ke liye
    public void ResetProgress()
    {
        PlayerPrefs.DeleteKey("UnlockedLevel");
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
