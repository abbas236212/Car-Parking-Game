using UnityEngine;

// Engine ki awaaz: car tez ho to awaaz bhi tez (pitch upar)
// Ye script PlayerCar par lagta hai
public class EngineSound : MonoBehaviour
{
    public AudioSource engine;      // Engine clip, Loop tick
    public float minPitch = 0.8f;   // car ruki ho
    public float maxPitch = 2.0f;   // full speed

    CarController car;

    void Start()
    {
        car = GetComponent<CarController>();
        if (engine != null) engine.Play();
    }

    void Update()
    {
        if (car == null || engine == null) return;

        // Game khatam (complete / fail) to engine band
        if (!car.controlsEnabled)
        {
            if (engine.isPlaying) engine.Stop();
            return;
        }

        float speed01 = Mathf.Abs(car.currentSpeed) / car.maxSpeed;   // 0 se 1
        engine.pitch = Mathf.Lerp(minPitch, maxPitch, speed01);
    }
}
