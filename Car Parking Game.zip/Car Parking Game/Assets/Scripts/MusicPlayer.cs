using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Background music poore game mein chalta rahe (scene badalne par bhi)
// Aur har button dabane par "click" ki awaaz
public class MusicPlayer : MonoBehaviour
{
    public AudioSource music;        // BG Music (Loop)
    public AudioSource clickSound;   // Button click

    static MusicPlayer instance;

    void Awake()
    {
        // Sirf ek MusicPlayer rahe (menu par wapas aane par doosra na bane)
        if (instance != null)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        DontDestroyOnLoad(gameObject);
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void Start()
    {
        if (music != null && !music.isPlaying) music.Play();
        AddClickToButtons();
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        AddClickToButtons();
    }

    // Scene ke saare buttons par click sound khud lag jata hai
    void AddClickToButtons()
    {
        if (clickSound == null) return;
        Button[] buttons = FindObjectsByType<Button>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (Button b in buttons)
        {
            b.onClick.AddListener(() => clickSound.Play());
        }
    }
}
