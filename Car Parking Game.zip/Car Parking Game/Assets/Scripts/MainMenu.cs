using UnityEngine;
using UnityEngine.SceneManagement;

// Main Menu ke buttons: PLAY aur QUIT
public class MainMenu : MonoBehaviour
{
    public string levelSelectScene = "LevelSelect";

    void Start()
    {
        Time.timeScale = 1f;
    }

    public void PlayGame()
    {
        SceneManager.LoadScene(levelSelectScene);
    }

    public void QuitGame()
    {
        Debug.Log("Quit");      // Editor mein sirf ye message aayega
        Application.Quit();     // Build (.exe) mein game band hoga
    }
}
