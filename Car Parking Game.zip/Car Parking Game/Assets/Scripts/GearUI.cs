using UnityEngine;
using UnityEngine.UI;
using TMPro;

// Screen par gear dikhata hai: D (neela) ya R (laal)
public class GearUI : MonoBehaviour
{
    public CarController car;            // yahan PlayerCar daalo
    public TextMeshProUGUI gearText;     // yahan GearText daalo
    public Image background;             // yahan GearBox daalo

    public Color driveColor = new Color(0.12f, 0.45f, 0.85f);   // neela
    public Color reverseColor = new Color(0.85f, 0.20f, 0.15f); // laal

    void Update()
    {
        if (car == null) return;

        bool reverse = car.isReverse;
        if (gearText != null) gearText.text = reverse ? "R" : "D";
        if (background != null) background.color = reverse ? reverseColor : driveColor;
    }
}
