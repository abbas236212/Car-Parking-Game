using UnityEngine;

// Car kisi barrel se takraye = LEVEL FAILED
// Ye script PlayerCar par lagta hai (jahan Rigidbody hai)
public class CrashDetector : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.IsGameOver()) return;

        // Barrel ya us ka koi hissa
        Transform t = collision.transform;
        bool hitBarrel = t.CompareTag("Barrel") ||
                         (t.parent != null && t.parent.CompareTag("Barrel"));

        if (hitBarrel)
        {
            GameManager.Instance.LevelFailed();
        }
    }
}
